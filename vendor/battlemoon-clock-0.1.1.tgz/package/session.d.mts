import type {Outcome, TimeHost} from '@battlemoon/component-contracts';
import type {ClockConfig,ClockViewModel} from './core.mjs';
export interface ClockHost extends TimeHost {schedule(callback:()=>void,intervalMilliseconds:number):()=>void;reportFailure?(failure:{code:'unavailable';message:string}):void}
export function createClockSession(options:{instanceId:string;host:ClockHost;config?:Partial<ClockConfig>;onChange:(result:Outcome<ClockViewModel>)=>void}): {
  refresh():Promise<void>;resume():void;suspend():Outcome<void>;dispose():Outcome<void>;
  updateConfig(config:Partial<ClockConfig>):Outcome<Readonly<ClockConfig>>;
};
