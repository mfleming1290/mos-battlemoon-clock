import {sampleTime} from '@battlemoon/component-contracts';
import {clockViewModel,validateClockConfig,defaultClockConfig} from './core.mjs';
// Clock-specific effect lifetime; scheduling/native policy still belongs to host.
export function createClockSession({instanceId,host,config=defaultClockConfig,onChange}) {
  let current=config,active=false,disposed=false,generation=0,stop,signal;
  function invalidate() {generation++;if(signal)signal.aborted=true;}
  async function refresh() {
    if(!active||disposed)return;
    invalidate();const ticket=generation;const cancellation={aborted:false};signal=cancellation;
    const result=await sampleTime(host,instanceId,cancellation);
    if(disposed||!active||ticket!==generation)return;
    onChange(result.code==='success'?clockViewModel(result.value,current):result);
  }
  function suspend() {
    active=false;invalidate();const release=stop;stop=undefined;
    try {release?.();return {code:'success',value:undefined};}
    catch {
      const failure={code:'unavailable',message:'Clock cleanup failed'};
      // Optional diagnostics cannot veto teardown or the original bounded result.
      try {host?.reportFailure?.(failure);} catch {}
      return failure;
    }
  }
  function resume() {
    if(disposed||active)return;
    if(typeof host?.schedule!=='function'){onChange({code:'unsupported',message:'Clock scheduling not supplied'});return;}
    active=true;
    try {stop=host?.schedule?.(()=>void refresh(),1000);}
    catch {active=false;invalidate();onChange({code:'unavailable',message:'Clock scheduling failed'});return;}
    void refresh();
  }
  return {
    refresh,resume,suspend,
    updateConfig(next) {const checked=validateClockConfig(next);if(checked.code!=='success')return checked;current=checked.value;invalidate();if(active)void refresh();return checked;},
    dispose() {if(disposed)return {code:'success',value:undefined};disposed=true;return suspend();},
  };
}
