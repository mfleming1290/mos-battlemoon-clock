import type {DefineComponent} from 'vue';
import type {ClockConfig} from './core.mjs';
import type {ClockHost} from './session.mjs';
export const Clock: DefineComponent<{instanceId:string;host:ClockHost;config?:Partial<ClockConfig>;active?:boolean}>;
