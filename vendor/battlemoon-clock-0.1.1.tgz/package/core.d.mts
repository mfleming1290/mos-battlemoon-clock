export interface ClockConfig {locale: string; timeZone: string; seconds: boolean; hour12: boolean}
export interface ClockViewModel {text: string; hour: string; minute: string; second: string|null; dayPeriod: string|null; dateTime: string; timeZone: string}
export type ClockResult = {code:'success';value:ClockViewModel}|{code:'invalid';message:string};
export const clockDescriptor: Readonly<{id:string;version:string;contractRevision:number;requiredCapabilities:readonly string[]}>;
export const defaultClockConfig: Readonly<ClockConfig>;
export function validateClockConfig(input: unknown): {code:'success';value:Readonly<ClockConfig>}|{code:'invalid';message:string};
export function clockViewModel(epochMilliseconds: number,input?: Partial<ClockConfig>): ClockResult;
