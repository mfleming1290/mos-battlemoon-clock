import {defineComponent,h,shallowRef,watchEffect} from 'vue';
import {createClockSession} from './session.mjs';
import {defaultClockConfig} from './core.mjs';
export const Clock=defineComponent({name:'BattlemoonClock',props:{instanceId:{type:String,required:true},host:{type:Object,required:true},config:{type:Object,default:()=>defaultClockConfig},active:{type:Boolean,default:true}},setup(props){
  const result=shallowRef();
  watchEffect(onCleanup=>{const session=createClockSession({instanceId:props.instanceId,host:props.host,config:props.config,onChange:value=>result.value=value});if(props.active)session.resume();onCleanup(()=>session.dispose());});
  return ()=>h('output',{'data-clock-instance':props.instanceId,'data-clock-status':result.value?.code??'pending','aria-label':'Clock'},result.value?.code==='success'?result.value.value.text:result.value?.message??'Clock');
}});
