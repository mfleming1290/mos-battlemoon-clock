export const clockDescriptor=Object.freeze({id:'battlemoon.clock',version:'0.1.1',contractRevision:1,requiredCapabilities:Object.freeze(['time'])});
export const defaultClockConfig=Object.freeze({locale:'en-GB',timeZone:'UTC',seconds:true,hour12:false});
export function validateClockConfig(input) {
  if(!input||typeof input!=='object'||Array.isArray(input))return {code:'invalid',message:'Clock configuration required'};
  if(Object.keys(input).some(k=>!['locale','timeZone','seconds','hour12'].includes(k)))return {code:'invalid',message:'Unknown Clock configuration field'};
  const config={...defaultClockConfig,...input};
  if(typeof config.locale!=='string'||!config.locale||typeof config.timeZone!=='string'||!config.timeZone||typeof config.seconds!=='boolean'||typeof config.hour12!=='boolean')return {code:'invalid',message:'Invalid Clock configuration'};
  try {
    Intl.getCanonicalLocales(config.locale);
    new Intl.DateTimeFormat(config.locale,{timeZone:config.timeZone});
    return {code:'success',value:Object.freeze(config)};
  }catch {return {code:'invalid',message:'Invalid locale or time zone'};}
}
export function clockViewModel(epochMilliseconds,input=defaultClockConfig) {
  const checked=validateClockConfig(input);if(checked.code!=='success')return checked;
  if(typeof epochMilliseconds!=='number'||!Number.isFinite(epochMilliseconds)||Math.abs(epochMilliseconds)>8.64e15)return {code:'invalid',message:'Invalid Clock time'};
  const config=checked.value;
  const date=new Date(epochMilliseconds);
  const options={timeZone:config.timeZone,hour:'2-digit',minute:'2-digit',hourCycle:config.hour12?'h12':'h23',...(config.seconds?{second:'2-digit'}:{})};
  const formatter=new Intl.DateTimeFormat(config.locale,options);
  const parts=Object.fromEntries(formatter.formatToParts(date).map(p=>[p.type,p.value]));
  return {code:'success',value:{text:formatter.format(date),hour:parts.hour,minute:parts.minute,second:parts.second??null,dayPeriod:parts.dayPeriod??null,dateTime:date.toISOString(),timeZone:config.timeZone}};
}
