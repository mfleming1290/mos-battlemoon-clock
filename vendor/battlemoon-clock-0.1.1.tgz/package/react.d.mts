import type {ReactElement} from 'react';
import type {ClockConfig} from './core.mjs';
import type {ClockHost} from './session.mjs';
export function Clock(props:{instanceId:string;host:ClockHost;config?:Partial<ClockConfig>;active?:boolean}):ReactElement;
