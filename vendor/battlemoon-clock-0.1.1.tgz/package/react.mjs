import {createElement,useEffect,useState} from 'react';
import {createClockSession} from './session.mjs';
import {defaultClockConfig} from './core.mjs';
export function Clock({instanceId,host,config=defaultClockConfig,active=true}) {
  const [result,setResult]=useState();
  useEffect(()=>{
    const session=createClockSession({instanceId,host,config,onChange:setResult});
    if(active)session.resume();
    return ()=>session.dispose();
  },[instanceId,host,config,active]);
  return createElement('output',{'data-clock-instance':instanceId,'data-clock-status':result?.code??'pending','aria-label':'Clock'},result?.code==='success'?result.value.text:result?.message??'Clock');
}
