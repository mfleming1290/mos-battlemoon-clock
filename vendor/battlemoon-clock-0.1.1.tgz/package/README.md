# @battlemoon/clock 0.1.1

One pure Clock domain/configuration implementation, shared React/Vue projections.
Import `@battlemoon/clock` for deterministic `clockViewModel(time, config)` only;
it initializes no timers, framework, DOM, network or desktop runtime. Locale/time
zone inputs are explicit. Numeric fixtures are stable; ICU-localized display text
is not a universal cross-machine byte promise. Malformed locales, unsupported
timezones and invalid fields return invalid. Well-formed locales follow Intl's
host locale fallback; supported locale data is not promised on every host.

`/session` uses a supplied host's typed time/scheduler functions, not native/RPC
authority. Host scheduling returns a disposer; host visibility decides suspension.
Refresh/configuration generations fence late results. Repeated disposal is safe.
Cleanup failure returns redacted unavailable even if the optional failure reporter
also throws. Cancellation fences read results; it does not prove producer stop.
`/react` and `/vue` are thin optional peer-framework projections; core semantics
are not copied. No bundled framework, database, storage or global timer exists.
Config maps to the separate Skir ClockConfig revision through host fixtures.

Host adapters own persisted config, placement, identity, lock, views, theme and
security. This package is trusted static code, not an installed portable plugin.
Use `node tools/check-clock.mjs` in the private repository for proof tests.
Battle and MOS must consume identical package inputs; a Vue proof is not MOS.
