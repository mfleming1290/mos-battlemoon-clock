import {TimeResult} from './generated/typescript/skirout/component.js';
const failures=new Set(['unsupported','denied','invalid','unavailable','cancelled']);
const invalid=message=>({code:'invalid',message});
function validate(result) {
  if(result?.code==='success')return Number.isFinite(result.value)&&Math.abs(result.value)<=8.64e15
    ? {code:'success',value:result.value}:invalid('Invalid time');
  if(failures.has(result?.code)&&typeof result.message==='string')return {code:result.code,message:result.message};
  return invalid('Invalid host outcome');
}
export async function sampleTime(host,instanceId,cancellation) {
  if(cancellation.aborted)return {code:'cancelled',message:'Cancelled'};
  if(typeof instanceId!=='string'||!instanceId.trim()||instanceId.trim()!==instanceId)return invalid('Invalid instance identity');
  if(!host)return {code:'unsupported',message:'Time capability not supplied'};
  try {
    const result=validate(await host.readTime({instanceId},cancellation));
    return cancellation.aborted?{code:'cancelled',message:'Cancelled'}:result;
  } catch {
    // This is a side-effect-free read, not proof that a mutation had no effect.
    if(cancellation.aborted)return {code:'cancelled',message:'Cancelled'};
    return {code:'unavailable',message:'Time capability failed'};
  }
}
export function encodeTimeResult(result) {
  const valid=validate(result);
  return TimeResult.serializer.toBytes(TimeResult.create({code:valid.code.toUpperCase(),epochMilliseconds:valid.code==='success'?valid.value:0,message:valid.code==='success'?'':valid.message})).toBuffer();
}
export function decodeTimeResult(bytes) {
  const wire=TimeResult.serializer.fromBytes(bytes);
  const code=wire.code.kind.toLowerCase();
  return validate(code==='success'?{code,value:wire.epochMilliseconds}:{code,message:wire.message});
}
