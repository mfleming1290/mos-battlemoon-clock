export type FailureCode = "unsupported" | "denied" | "invalid" | "unavailable" | "cancelled";
export type Outcome<T> = {code: "success"; value: T} | {code: FailureCode; message: string};
export interface Cancellation { readonly aborted: boolean }
export interface TimeHost {
  readTime(request: {instanceId: string}, cancellation: Cancellation): Promise<Outcome<number>>;
}
export interface ComponentDescriptor {
  readonly id: string;
  readonly version: string;
  readonly contractRevision: number;
  readonly requiredCapabilities: readonly string[];
}
export function sampleTime(host: TimeHost | undefined, instanceId: string, cancellation: Cancellation): Promise<Outcome<number>>;
export function encodeTimeResult(result: Outcome<number>): Uint8Array;
export function decodeTimeResult(bytes: Uint8Array): Outcome<number>;
