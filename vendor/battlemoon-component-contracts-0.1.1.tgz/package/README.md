# Minimal component contract 0.1.1

Static typed `ComponentDescriptor` plus direct per-instance `TimeHost.readTime`.
No runtime registry, desktop dependency, networking, permission authority or RPC.
`sampleTime` validates host identity/outcomes and cancellation. Host exceptions
become unavailable without leaking exception text unless this side-effect-free
read has been cancelled, which yields cancelled. Cancellation suppresses results;
it does not prove a producer stopped or an uncertain mutation had no effect.
Advertised capability is not
authorization; the host returns denied independently of registration.

Skir owns four separate component records and their compatibility snapshot.
The domain facade maps lowercase outcomes to generated TypeScript enum values.
Use dense numeric JSON or binary for cross-language fixtures: pinned generators
use different readable constant names (TypeScript uppercase, Rust lowercase).
No codec implementation/wire change is made to hide that tooling distinction.
Unknown outcomes and non-finite/out-of-Date-range timestamps return invalid.

Run `node tools/check-components.mjs` from the repository root. This proves
generation determinism, four-language JSON/binary parity, compatibility and
deliberate field-type rejection, codec-only graph and six outcomes. Generated
DTOs are not native Clock/domain or host implementations. Optional Skir method
descriptors are not required; direct typed functions are the selected seam.
